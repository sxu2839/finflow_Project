// Top-level build file where you can add configuration options common to all sub-projects/modules.
// In the project-level build.gradle.kts file



plugins {
    id("com.android.application") version "8.2.1" apply false
    id("com.google.gms.google-services") version "4.4.1" apply false
}



