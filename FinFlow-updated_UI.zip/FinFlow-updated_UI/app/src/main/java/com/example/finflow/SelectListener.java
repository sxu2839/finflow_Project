package com.example.finflow;

import com.example.finflow.Models.NewsHeadlines;

public interface SelectListener {
    void OnNewsClicked(NewsHeadlines headlines);
}
