package com.example.finflow;

import junit.framework.TestCase;

public class ItemTest extends TestCase {

}